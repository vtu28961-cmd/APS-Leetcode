/**
 * Definition for singly-linked list.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode() {}
 *     ListNode(int val) { this.val = val; }
 *     ListNode(int val, ListNode next) { this.val = val; this.next = next; }
 * }
 */
class Solution {
    public ListNode reverseList(ListNode head) {
        ListNode prev,current,nextnode;
        prev =null;
        current=head;
        while(current!=null){
            nextnode=current.next;
            current.next=prev;
            prev =current;
            current=nextnode;
        }
        head=prev;
        return head;

        
    }
}