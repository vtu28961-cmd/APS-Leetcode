

class Solution {
    public int[] maxSlidingWindow(int[] nums, int k) {
        Deque<Integer> dq = new ArrayDeque<>();
        int n = nums.length;
        int[] ans = new int[n - k + 1];
        int i, j = 0;
        
        for (i = 0; i < n; i++) {
            while (!dq.isEmpty() && dq.peekFirst() <= i - k)
                dq.pollFirst();
            while (!dq.isEmpty() && nums[i] >= nums[dq.peekLast()])
                dq.pollLast();
            dq.offerLast(i);
            if (i >= k - 1)
                ans[j++] = nums[dq.peekFirst()];
        }
        return ans;
    }
}